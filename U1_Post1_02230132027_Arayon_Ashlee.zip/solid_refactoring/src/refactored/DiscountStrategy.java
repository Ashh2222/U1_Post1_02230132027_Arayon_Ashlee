package refactored;

public interface DiscountStrategy {
	double applyDiscount(double total);
}


