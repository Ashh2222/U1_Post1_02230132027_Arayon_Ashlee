package original;

public class Main {
    public static void main(String[] args) {

        OrderManager order = new OrderManager();
        order.createOrder("Ash", "Laptop", 2000, 2);
        order.generateReport();
    }
}